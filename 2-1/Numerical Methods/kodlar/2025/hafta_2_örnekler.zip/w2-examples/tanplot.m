%% this code is ... 
clc
clear all
close all 
theta = linspace(1.6,4.6);
tandata = tan(theta);
plot(theta,tandata);
xlabel('\theta     (radians)');
ylabel('tan(\theta)'); % ylabel 
grid on;
axis([min(theta) max(theta) -5 5]);
