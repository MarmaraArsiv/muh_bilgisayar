x = 16;
if x < 0
    error('x is negative; sqrt(x) is imaginary');
else
    r = sqrt(x);
end
r

color='red';
switch color
    case 'red'
        disp('color is red')
    case 'red'
        disp('color is red')
    otherwise
        disp('other')
end